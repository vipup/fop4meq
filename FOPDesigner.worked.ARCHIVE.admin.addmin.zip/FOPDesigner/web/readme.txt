In order to reduce the size of the download we have place the WAR file in a separate URL:

http://www.java4less.com/fopdesigner/J4LFOPServer.war