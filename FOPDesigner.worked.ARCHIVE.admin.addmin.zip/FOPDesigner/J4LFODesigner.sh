export JAVA_HOME=/usr/lib/jvm/java-8-oracle
export PATH=$PATH:$JAVA_HOME/bin
export PATH=$PATH:$JAVA_HOME/jre/bin
java  -Xmx1024M -jar j4lFODesigner.jar localdb dbdir="db/j4lfopdb"
