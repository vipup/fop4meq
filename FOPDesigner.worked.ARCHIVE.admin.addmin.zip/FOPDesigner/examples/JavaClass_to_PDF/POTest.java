import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.java4less.examples.po.PurchaseOrderHeader;
import com.java4less.examples.po.BuyerInformation;
import com.java4less.examples.po.PurchaseOrderItem;
import com.java4less.xreport.fop.FOProcessor;


public class POTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// 1. create order
		PurchaseOrderHeader po=new PurchaseOrderHeader("1");
		po.setBuyer(new BuyerInformation("John Solo","Street ABC 1","Manchester","AB 673","UK"));
		PurchaseOrderItem[] items={ new PurchaseOrderItem("X1","Printer Injet",1),
				 new PurchaseOrderItem("R4","Optic mouse",1),
				 new PurchaseOrderItem("M3","Ergo keyboard",1),
				 new PurchaseOrderItem("X4","CD-RW",10)
		};
		po.setItems(items);
		


		try {

			// 2. create now XML representation of the order			
			JAXBContext jc = JAXBContext.newInstance(PurchaseOrderHeader.class);
			Marshaller marshaller=jc.createMarshaller();
			ByteArrayOutputStream ba=new ByteArrayOutputStream();
			marshaller.marshal(po,ba);
			
			System.out.println("Created XML= "+new String(ba.toByteArray()));
			
			// 3. create now the PDF output for the XML data
			FOProcessor processor=new FOProcessor();
			processor.process(new ByteArrayInputStream(ba.toByteArray()), new FileInputStream("JavaPOExample.fo") , new FileOutputStream("JavaPOExample.pdf"));

			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
